from django.db import models

class CreateDisciplineModel(models.Model):
    Name = models.CharField('Название', max_length=30)

class DeleteDisciplineModel(models.Model):
    Id = models.IntegerField('Айди дисциплины')
class UserModel(models.Model):
    Name = models.CharField('Имя', max_length=30)

class TeamModel(models.Model):
    Name = models.CharField('Название команды', max_length=30)

class TournamentModel(models.Model):
    TournamentName = models.CharField('Название турнира', max_length=30)
    DisciplineId = models.IntegerField('Айди дисциплины')
    OwnerId = models.IntegerField('Айди создателя турнира')


class AddTeamInTournamentModel(models.Model):
    IdTeam = models.IntegerField('Айди команды')
    IdTournament = models.IntegerField('Айди турнира, в который хотим добавить')
    Mesto = models.CharField('Место', max_length=30)
    Time = models.IntegerField('Время')

class GetTournamentTimeByTournamentIdModel(models.Model):
    Id = models.IntegerField('Айди турнира')

class GetTournamentMestoByTournamentIdModel(models.Model):
    Id = models.IntegerField('Айди турнира')

class GetAllTournamentsWhereParticipatedTeamByTeamIdModel(models.Model):
    Id = models.IntegerField('Айди команды')

class GetParticipantsByTeamIdModel(models.Model):
    Id = models.IntegerField('Айди команды')

class GetTeamNameByTournamentIdModel(models.Model):
    Id = models.IntegerField('Айди турнира')

class AddUserInTeamModel(models.Model):
    UserId = models.IntegerField('Айди Юзера')
    TeamId = models.IntegerField('Айди Команды, в которую хотим добавить')

class UpdateTournamentMestoModel(models.Model):
    IdTournament = models.IntegerField('Айди турнира')
    Mesto = models.CharField('Название места', max_length=100)

class UpdateTournamentTimeModel(models.Model):
    IdTournament = models.IntegerField('Айди турнира')
    Time = models.IntegerField('Время')

class DeleteTeamFromTournamentModel(models.Model):
    TeamId = models.IntegerField('Айди команды')

class DeleteUserFromTeamModel(models.Model):
    UserId = models.IntegerField('Айди Юзера')

class DeleteTournamentModel(models.Model):
    TournamentId = models.IntegerField('Айди турнира')

class DeleteUserModel(models.Model):
    UserId = models.IntegerField('Айди Юзера')

class DeleteTeamModel(models.Model):
    TeamId = models.IntegerField('Айди команды')