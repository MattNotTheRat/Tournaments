#from views import *
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.get_index),
    path('UserProcedures', views.UserProcedures),
    path('TeamProcedures', views.TeamProcedures),
    path('TournamentProcedures', views.TournamentProcedures),
    path('UserTable',views.User_Table),
    path('TournamentTable',views.Tournament_Table),
    path('TeamTable',views.Team_Table),
    path('DisciplineTable',views.Discipline_Table),
    path('Team_TournamentTable',views.Team_TournamentTable),
    path('User_TeamTable',views.User_TeamTable)
]