from .models import *
from django.forms import ModelForm

class UserForm(ModelForm):
    class Meta:
        model = UserModel
        fields=["Name"]

class TeamForm(ModelForm):
    class Meta:
        model = TeamModel
        fields = ["Name"]

class TournamentForm(ModelForm):
    class Meta:
        model = TournamentModel
        fields = ["TournamentName", "DisciplineId", "OwnerId"]


class AddTeamInTournamentForm(ModelForm):
    class Meta:
        model = AddTeamInTournamentModel
        fields = ["IdTeam","IdTournament","Mesto","Time"]

class GetTournamentTimeByTournamentIdForm(ModelForm):
    class Meta:
        model = GetTournamentTimeByTournamentIdModel
        fields = ["Id"]

class GetTournamentMestoByTournamentIdForm(ModelForm):
    class Meta:
        model = GetTournamentMestoByTournamentIdModel
        fields = ["Id"]

class GetAllTournamentsWhereParticipatedTeamByTeamIdForm(ModelForm):
    class Meta:
        model = GetAllTournamentsWhereParticipatedTeamByTeamIdModel
        fields = ["Id"]

class GetParticipantsByTeamIdForm(ModelForm):
    class Meta:
        model = GetParticipantsByTeamIdModel
        fields = ["Id"]

class GetTeamNameByTournamentIdForm(ModelForm):
    class Meta:
        model = GetTeamNameByTournamentIdModel
        fields = ["Id"]

class AddUserInTeamForm(ModelForm):
    class Meta:
        model = AddUserInTeamModel
        fields = ["UserId","TeamId"]

class UpdateTournamentMestoForm(ModelForm):
    class Meta:
        model = UpdateTournamentMestoModel
        fields = ["IdTournament","Mesto"]

class UpdateTournamentTimeForm(ModelForm):
    class Meta:
        model = UpdateTournamentTimeModel
        fields = ["IdTournament","Time"]

class DeleteTeamFromTournamentForm(ModelForm):
    class Meta:
        model = DeleteTeamFromTournamentModel
        fields = ["TeamId"]

class DeleteUserFromTeamForm(ModelForm):
    class Meta:
        model = DeleteUserFromTeamModel
        fields = ["UserId"]

class DeleteTournamentForm(ModelForm):
    class Meta:
        model = DeleteTournamentModel
        fields = ["TournamentId"]

class DeleteUserForm(ModelForm):
    class Meta:
        model = DeleteUserModel
        fields = ["UserId"]

class DeleteTeamForm(ModelForm):
    class Meta:
        model = DeleteTeamModel
        fields = ["TeamId"]


