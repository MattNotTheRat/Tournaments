from django.shortcuts import render
from .forms import *
from .Procedures import *

def get_index(request):
    return render(request, "main/GGGGEEEE.html")

def User_Table(request):
    table = SelectUser()
    data = {
        'data1': table
    }
    return render(request, "main/UserTable.html", data)

def UserProcedures(request):
    if request.method=='POST':
            formq = UserForm(request.POST)
            if formq.is_valid():
                CreateUser(formq.data['Name'])
            formp = AddUserInTeamForm(request.POST)
            if formp.is_valid():
                AddUserInTeam(formp.data['UserId'], formp.data['TeamId'])
            formf = DeleteUserFromTeamForm(request.POST)
            if formf.is_valid():
                DeleteUserFromTeam(formf.data['UserId'])
            formh = DeleteUserForm(request.POST)
            if formh.is_valid():
                DeleteUser(formh.data['UserId'])

    formq = UserForm
    formp = AddUserInTeamForm
    formf = DeleteUserFromTeamForm
    formh = DeleteUserForm

    data = {
        'UserForm': formq,
        'AddUserInTeamForm': formp,
        'DeleteUserFromTeamForm': formf,
        'DeleteUserForm': formh
    }
    return render(request, "main/UserProcedures.html", data)

def TeamProcedures(request):
    if request.method=='POST':
        formw = TeamForm(request.POST)
        if formw.is_valid():
            CreateTeam(formw.data['Name'])
        formr = AddTeamInTournamentForm(request.POST)
        if formr.is_valid():
            AddTeamInTournament(formr.data['IdTeam'], formr.data['IdTournament'], formr.data['Mesto'], formr.data['Time'])
        formi = GetParticipantsByTeamIdForm(request.POST)
        if formi.is_valid():
            GetParticipantsByTeamId(formi.data['Id'])
        formo = GetTeamNameByTournamentIdForm(request.POST)
        if formo.is_valid():
            GetTeamNameByTournamentId(formo.data['Id'])
        formd = DeleteTeamFromTournamentForm(request.POST)
        if formd.is_valid():
            DeleteTeamFromTournament(formd.data['TeamId'])
        formj = DeleteTeamForm(request.POST)
        if formj.is_valid():
            DeleteTeam(formj.data['TeamId'])

    formw = TeamForm
    formr = AddTeamInTournamentForm
    formi = GetParticipantsByTeamIdForm
    formo = GetTeamNameByTournamentIdForm
    formd = DeleteTeamFromTournamentForm
    formj = DeleteTeamForm
    data = {
        'TeamForm': formw,
        'AddTeamInTournamentForm': formr,
        'GetParticipantsByTeamIdForm': formi,
        'GetTeamNameByTournamentIdForm': formo,
        'DeleteTeamFromTournamentForm': formd,
        'DeleteTeamForm': formj
    }
    return render(request, "main/TeamProcedures.html", data)

def TournamentProcedures(request):
    if request.method=='POST':
        forme = TournamentForm(request.POST)
        if forme.is_valid():
            CreateTournament(forme.data['TournamentName'], forme.data['DisciplineId'], forme.data['OwnerId'])
        formt = GetTournamentTimeByTournamentIdForm(request.POST)
        if formt.is_valid():
            GetTournamentTimeByTournamentId(formt.data['Id'])
        formy = GetTournamentMestoByTournamentIdForm(request.POST)
        if formy.is_valid():
            GetTournamentMestoByTournamentId(formy.data['Id'])
        formu = GetAllTournamentsWhereParticipatedTeamByTeamIdForm(request.POST)
        if formu.is_valid():
            GetAllTournamentsWhereParticipatedTeamByTeamId(formu.data['Id'])
        forma = UpdateTournamentMestoForm(request.POST)
        if forma.is_valid():
            UpdateTournamentMesto(forma.data['IdTournament'], forma.data['Mesto'])
        forms = UpdateTournamentTimeForm(request.POST)
        if forms.is_valid():
            UpdateTournamentTime(forms.data['IdTournament'], forms.data['Time'])
        formg = DeleteTournamentForm(request.POST)
        if formg.is_valid():
            DeleteTournament(formg.data['TournamentId'])
    forme = TournamentForm
    formt = GetTournamentTimeByTournamentIdForm
    formy = GetTournamentMestoByTournamentIdForm
    formu = GetAllTournamentsWhereParticipatedTeamByTeamIdForm
    forma = UpdateTournamentMestoForm
    forms = UpdateTournamentTimeForm
    formg = DeleteTournamentForm
    data = {
        'TournamentForm': forme,
        'GetTournamentTimeByTournamentIdForm': formt,
        'GetTournamentMestoByTournamentIdForm': formy,
        'GetAllTournamentsWhereParticipatedTeamByTeamIdForm': formu,
        'UpdateTournamentMestoForm': forma,
        'UpdateTournamentTimeForm': forms,
        'DeleteTournamentForm': formg
    }
    return render(request, "main/TournamentProcedures.html", data)
