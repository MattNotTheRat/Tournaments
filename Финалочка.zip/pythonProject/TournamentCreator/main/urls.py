#from views import *
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.get_index),
    path('UserProcedures', views.UserProcedures),
    path('TeamProcedures', views.TeamProcedures),
    path('TournamentProcedures', views.TournamentProcedures)
]